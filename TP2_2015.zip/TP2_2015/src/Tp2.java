import java.io.*;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class Tp2 {
    public static void main(String[] args) throws FileNotFoundException {
        //Variables
        Tp2 sys = new Tp2();
        LocalDate currentDate = null;
        int etat = 0;
        int prescriptionNumber = 1;
        StringBuilder finalMessage = new StringBuilder("");

        //ABR
        TreeMap<LocalDate, Medicament> inventory = new TreeMap<>();
        TreeMap<String, Medicament> commandes = new TreeMap<>();
        TreeMap<String, Medicament> prescriptions = new TreeMap<>();
        TreeMap<String, Medicament> stock = new TreeMap<>();

        //Path des fichiers
        String fileInput = "testsE23/tests/"+ args[0];
        String fileOutput = "output/"+ args[1];

        //Lecture fichier d'input
        File myObj = new File(fileInput);
        Scanner myReader = new Scanner(myObj);
        while (myReader.hasNextLine()) {
            String data = myReader.nextLine();

            String[] info = data.split("\\s+");
            String command = info[0];
            if(Objects.equals(command, "DATE")){
                etat = 1;

            }else if(Objects.equals(command, "APPROV")){
                etat = 2;

            }else if(Objects.equals(command, "PRESCRIPTION")){
                etat = 3;
                finalMessage.append("PRESCRIPTION ").append(prescriptionNumber).append("\n");

                prescriptionNumber++;
            }else if(Objects.equals(command, "STOCK")){
                etat = 4;
            }
            switch (etat) {
                case 1 -> { //command DATE
                    currentDate = sys.commandDate(currentDate,finalMessage, commandes, info);
                }
                case 2 -> { //command APPROV
                    sys.commandApprov(info,  inventory, finalMessage);
                }
                case 3 -> { //command PRESCRIPTION
                    sys.commandPrescription(info, inventory, commandes, finalMessage, currentDate, prescriptions);
                }
                case 4 -> { //command STOCK
                    sys.commandStock(info, currentDate, inventory, stock, finalMessage);

                }
            }
        }
        myReader.close();
        //Écriture dans le fichier d'output
        sys.finalMessage(fileOutput, String.valueOf(finalMessage));
    }
    public void finalMessage(String filePath, String finalMessage){
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
                writer.write(finalMessage);

        } catch (IOException e) {
            System.out.println("An error occurred while writing to the file: " + e.getMessage());
        }

    }
    //Fonction en charge de gérer la commande "DATE"
    public LocalDate commandDate(LocalDate currentDate,StringBuilder finalMessage, TreeMap<String,
                                                                   Medicament>commandes, String[] info){
        if (!Objects.equals(info[0], ";")) {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            if (commandes.isEmpty()) {
                currentDate = LocalDate.parse(info[1], formatter);
                if (currentDate.isBefore(LocalDate.of(2000, 1, 1)) ||
                        currentDate.isAfter(LocalDate.of(2025, 1, 1))) {
                    throw new DateTimeException("Invalid Date");
                } else {
                    finalMessage.append(currentDate).append(" OK").append("\n");
                }
            } else {
                currentDate = LocalDate.parse(info[1], formatter);
                finalMessage.append(currentDate).append(" COMMANDES :").append("\n");

                for (String key : commandes.keySet()) {
                    Medicament commandMed = commandes.get(key);
                    finalMessage.append(commandMed.getName()).append(" ").
                            append(commandMed.getQuantity()).append("\n");
                }
            }
            finalMessage.append("\n");

            return currentDate;
        }else{
            return currentDate;
        }
    }
    //Fonction en charge de gérer la commande "APPROV"
    public void commandApprov(String[] info, TreeMap<LocalDate, Medicament> inventory, StringBuilder finalMessage){
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        if (info.length == 3) {
            String name = info[0];
            int quantity = Integer.parseInt(info[1]);
            LocalDate expiryDate = LocalDate.parse(info[2], formatter);
            Medicament medicament = new Medicament(name, quantity, expiryDate);
            inventory.put(medicament.getExpiryDate(), medicament);

        } else if (Objects.equals(info[0], ";")) {
            finalMessage.append("APPROV OK").append("\n");
        }
    }
    //Fonction en charge de gérer la commande "PRESCRIPTION"
    public void commandPrescription(String[] info, TreeMap<LocalDate, Medicament> inventory, TreeMap<String,
                                   Medicament> commandes, StringBuilder finalMessage, LocalDate currentDate,
                                    TreeMap<String, Medicament> prescriptions){

        if (info.length == 3) {
            boolean found = false;

            String name = info[0];
            int doses = Integer.parseInt(info[1]);
            int cycles = Integer.parseInt(info[2]);
            int totalMeds = doses * cycles;
            long treatmentDays = (long) doses * cycles;
            //Trie selon la date la plus proche de la date actuelle
            LocalDate targetDate = currentDate;
            Comparator<LocalDate> comparator = Comparator.comparingLong(date -> Math.abs(date.toEpochDay() - targetDate.toEpochDay()));
            TreeMap<LocalDate, Medicament> inventory2 = new TreeMap<>(comparator);
            for (LocalDate key : inventory.keySet()) {
                Medicament medicament = inventory.get(key);
                inventory2.put(key, medicament);
            }

            //Cherche le medicament
            for (LocalDate key : inventory2.keySet()) {
                Medicament medicament = inventory2.get(key);
                if (Objects.equals(medicament.getName(), name)) {
                    boolean alternative = false;
                    found = true;
                    for (LocalDate key2 : inventory2.keySet()) {
                        Medicament medicament2 = inventory2.get(key2);
                        if(medicament2.getName().equals(medicament.getName())){
                            if(medicament2.getQuantity() > medicament.getQuantity() &&
                                    medicament2.getQuantity() < totalMeds){

                                alternative = true;
                            }
                        }
                    }
                    LocalDate checkDate = medicament.getExpiryDate().plusDays(treatmentDays);
                    //Traitement médicament expiré ou épuisé
                    if ((checkDate.isBefore(currentDate) || totalMeds > medicament.getQuantity()) && !alternative) {

                        Medicament commandMed = new Medicament(name, totalMeds, null);
                        String commandeMessage = name + " " + doses + " " + cycles + " " + " COMMANDE";
                        //additionne toutes les quantités d'un même médicament à commander
                        if (commandes.containsKey(commandMed.getName())) {
                            int oldQuantity = commandes.get(commandMed.getName()).getQuantity();
                            int newQuantity = oldQuantity + commandMed.getQuantity();
                            commandes.get(commandMed.getName()).setQuantity(newQuantity);
                        } else {
                            commandes.put(commandMed.getName(), commandMed);
                        }
                        finalMessage.append(commandeMessage).append("\n");
                    //Traitement médicament non expiré et non épuisé
                    } else if(prescriptions.containsKey(medicament.getName())){
                        medicament.setQuantity(medicament.getQuantity() - totalMeds);
                        String commande = name + " " + doses + " " + cycles + " " + " OK";
                        finalMessage.append(commande).append("\n");
                        prescriptions.put(medicament.getName(), medicament);
                    }
                }
            }
            //Traitement d'un médicament qui n'apparait pas dans le "inventory"
            if (!found) {
                String commande = name + " " + doses + " " + cycles + " " + " COMMANDE";
                finalMessage.append(commande).append("\n");

                Medicament commandMed = new Medicament(name, totalMeds, null);

                if (commandes.containsKey(commandMed.getName())) {
                    int oldQuantity = commandes.get(commandMed.getName()).getQuantity();
                    int newQuantity = oldQuantity + commandMed.getQuantity();
                    commandes.get(commandMed.getName()).setQuantity(newQuantity);
                } else {
                    commandes.put(commandMed.getName(), commandMed);
                }
            }
        }
        if(info[0].equals(";")){
            finalMessage.append("\n");
        }
    }
    //Fonction en charge de gérer la commande "STOCK"
    public void commandStock(String[] info, LocalDate currentDate, TreeMap<LocalDate,
                             Medicament> inventory, TreeMap<String, Medicament> stock, StringBuilder finalMessage){

        if(info[0].equals("STOCK")) {
            finalMessage.append("STOCK " + currentDate).append("\n");
            for (LocalDate key : inventory.keySet()) {

                Medicament medicament = inventory.get(key);
                LocalDate expiryDate = medicament.getExpiryDate();
                int quantity = medicament.getQuantity();
                String name = medicament.getName();

                if (expiryDate.isAfter(currentDate) && quantity > 0 ) {
                    if(stock.containsKey(name) && stock.get(name).getExpiryDate() != expiryDate){
                        if(stock.get(name).getExpiryDate().isAfter(expiryDate)){
                            String name2 = name + "$";
                            stock.put(name2, stock.get(name));
                            stock.replace(name, medicament);

                        }else{
                            String name2 = name + "$";
                            stock.put(name2, medicament);
                        }
                    }else{stock.put(name,medicament);}
                }
            }
            for (String key : stock.keySet()) {
                Medicament medicament = stock.get(key);
                LocalDate expiryDate = medicament.getExpiryDate();
                int quantity = medicament.getQuantity();
                if(expiryDate.isAfter(currentDate)) {
                    if (key.contains("$")) {
                        key = key.substring(0, key.length() - 1);
                    }
                    finalMessage.append(key + " " + quantity + " " + expiryDate).append("\n");

                }
            }
            finalMessage.append("\n");
        }
    }
}